
FAZON – Public Proofs & Publications
------------------------------------

This folder contains the public page /proof/ for embedding FAZON research
from Zenodo and GitHub into the main site infrastructure.

Embed includes:
 - Zenodo iframe of published paper
 - GitHub source reference
 - SHA256 hash of publication ZIP
 - Timeline of published entries

DOI: https://doi.org/10.5281/zenodo.16889459
